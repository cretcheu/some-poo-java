class Employer {
    private String name;
    private String product;
    private int price;

    public Employer(String name, String product, int price) {
        this.name = name;
        this.product = product;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public String getProduct() {
        return product;
    }

    public int getPrice() {
        return price;
    }
}

class Customer {
    private String name;
    private int budget;

    public Customer(String name, int budget) {
        this.name = name;
        this.budget = budget;
    }

    public String getName() {
        return name;
    }

    public int getBudget() {
        return budget;
    }

    public boolean canAfford(int price) {
        return budget >= price;
    }
}

class Market {
    private Employer[] employers;
    private Customer[] customers;

    public Market(Employer[] employers, Customer[] customers) {
        this.employers = employers;
        this.customers = customers;
    }

    public void start() {
        for (Employer employer : employers) {
            System.out.println("Employer " + employer.getName() + " is selling " + employer.getProduct() + " for " + employer.getPrice());
            for (Customer customer : customers) {
                System.out.print("Customer " + customer.getName() + " with budget " + customer.getBudget());
                if (customer.canAfford(employer.getPrice())) {
                    System.out.println(" can afford " + employer.getProduct());
                } else {
                    System.out.println(" cannot afford " + employer.getProduct());
                }
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Employer[] employers = new Employer[] {
                new Employer("John", "Apple", 5),
                new Employer("Jane", "Banana", 3)
        };
        Customer[] customers = new Customer[] {
                new Customer("Alice", 10),
                new Customer("Bob", 7)
        };
        Market market = new Market(employers, customers);
        market.start();
    }
}
