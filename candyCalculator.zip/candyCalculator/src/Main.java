import java.util.List;
import java.util.Scanner;
public class Main {
    int gumPrice = 3;
    int chocolateBarPrice = 5;


    public static void main(String[] args) {
        Scanner scanner = new Scanner();
        System.out.println("Quantos créditos tens?");
        int credits = scanner.nextInt();
        candyCalculator(credits);

        System.out.println("Chocolate(s)" + + );
    }
}
