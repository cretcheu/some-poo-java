import java.io.*;
class Natureza {

    void Natureza()
    {
    }
    void Animais()
    {
    }
}
class Gato extends Natureza {
    void Animal()
    {
        try {
            Animais();
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(System.in));
            System.out.println("Os animais são as especies mais abundantes na natureza");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    void Felinos()
    {
        Vida();
        System.out.println("Na natureza temos vida!");
    }

    private void Vida() {
    }

    public static void main(String args[])
    {
        System.out.println("O gato é um mamífero e carnívoro da família dos felídeos");
    }
}
