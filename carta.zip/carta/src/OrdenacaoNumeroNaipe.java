import java.util.List;

public class OrdenacaoNumeroNaipe extends AlgoritmoOrdenacao {
    @Override
    public List<Carta> ordenar(List<Carta> listaCartas) {
        listaCartas.sort((c1, c2) -> {
            int numeroCompare = c1.getNumero() - c2.getNumero();
            if (numeroCompare != 0) {
                return numeroCompare;
            } else {
                return c1.getNaipe().compareTo(c2.getNaipe());
            }
        });
        return listaCartas;
    }
}
