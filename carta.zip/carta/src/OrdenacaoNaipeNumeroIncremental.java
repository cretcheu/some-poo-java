import java.util.List;

public class OrdenacaoNaipeNumeroIncremental extends AlgoritmoOrdenacao {
    @Override
    public List<Carta> ordenar(List<Carta> listaCartas) {
        listaCartas.sort((c1, c2) -> {
            int naipeCompare = c1.getNaipe().compareTo(c2.getNaipe());
            if (naipeCompare != 0) {
                return naipeCompare;
            } else {
                return c1.getNumero() - c2.getNumero();
            }
        });
        return listaCartas;
    }
}
