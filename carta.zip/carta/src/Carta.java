public class Carta {
    private String naipe;
    private int numero;

    public Carta(String naipe, int numero) {
        this.naipe = naipe;
        this.numero = numero;
    }

    public String getNaipe() {
        return naipe;
    }

    public int getNumero() {
        return numero;
    }
}