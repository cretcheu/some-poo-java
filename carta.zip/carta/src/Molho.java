import java.util.List;

public class Molho {
    private List<Carta> cartas;

    public Molho(List<Carta> cartas) {
        this.cartas = cartas;
    }

    public List<Carta> ordenar(AlgoritmoOrdenacao algoritmo) {
        return algoritmo.ordenar(cartas);
    }
}
