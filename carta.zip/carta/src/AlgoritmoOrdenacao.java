import java.util.List;

    public abstract class AlgoritmoOrdenacao {
        public abstract List<Carta> ordenar(List<Carta> listaCartas);
        public static void main(String[] args) {
            System.out.println(
            );
        }
    }

