import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Animal {
    private String nome;
    private String descricao;
    private String raca;
    private double peso;
    private double altura;
    private boolean perigoso;
    private String comida;
    private int quantidadeComida;

    public Animal(String leão, String leãoAfricano, String leão1, int i, double v, boolean b, String carne, int i1) {
    }

    // Construtor, getters e setters aqui...

    // Método para marcar um animal como perigoso
    public void marcarComoPerigoso() {
        this.perigoso = true;
    }

    // Método para adicionar uma quantidade de comida ao animal
    public void alimentar(int quantidade) {
        this.quantidadeComida += quantidade;
    }

    // Método para eliminar todos os animais perigosos
    public static void eliminarAnimaisPerigosos(List<Animal> animais) {
        boolean b = animais.removeIf(animal -> (animal.perigoso());
    }

    // Método para listar os nomes de todos os animais
    public static void listarNomes(List<Animal> animais) {
        animais.forEach(animal -> System.out.println(animal.getNome()));
    }

    private boolean getNome() {

        return false;
    }

    // Método para colocar 10 Kg de comida a cada animal
    public static void alimentarAnimais(List<Animal> animais) {
        animais.forEach(animal -> animal.alimentar(10));
    }

    // Método para eliminar todos os animais que pesem menos de 10 quilos
    public static void eliminarAnimaisLeves(List<Animal> animais) {
        boolean c = animais.removeIf(animal -> animal.getPeso() < 10);
    }

    private boolean getPeso() {
        return false;
    }

    public class Main {
    public static void main(String[] args) {
        // Criar uma coleção de animais
        List<Animal> animais = new ArrayList<>();
        animais.add(new Animal("Leão", "Leão africano", "Leão", 150, 1.2, true, "Carne", 5));
        animais.add(new Animal("Elefante", "Elefante africano", "Elefante", 5000, 3.5, false, "Vegetação", 20));
        animais.add(new Animal("Tigre", "Tigre de Bengala", "Tigre", 200, 1.1, true, "Carne", 8));
        animais.add(new Animal("Girafa", "Girafa comum", "Girafa", 1200, 5.5, false, "Vegetação", 15));

        // Eliminar todos os animais perigosos
        Scanner scanner = new Scanner;
        System.out.println("Digite o nome do animal pretendido?");
        int animal = scanner.nextInt();
        System.out.println("Nomes dos animais: " + animal);


        // Colocar 10 Kg de comida a cada animal
        animais.forEach(animal -> animal.alimentar(10));

        // Eliminar todos os animais que pesem menos de 10 quilos
        animais.removeIf(animal -> animal.getPeso() < 10);

        // Exibir os animais restantes
        System.out.println("Animais após as operações:");
        animais.forEach(System.out::println);
    }
}
}
